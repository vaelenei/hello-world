function validate(){
  alert("It's ok");
}
